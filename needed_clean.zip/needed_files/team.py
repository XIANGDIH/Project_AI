# COMP30024 Artificial Intelligence, Semester 1 2026
# Project Partner Nomination

# Fill in your team details here. Be sure to keep a copy of this file for use in
# future project submissions (this is how we identify your team).

metadata = {
    # Choose a team name! Try to make it unique in some way, as it will be
    # used to identify your team in the tournament at the end of the semester.
    # - Allowed characters: A-Z, a-z, 0-9, -, _ (no spaces allowed)
    # - Minimum length: 3 characters
    # - Maximum length: 20 characters
    "team_name": f"GOH1", 

    # Fill in the student IDs and emails of both team members here. There must
    # be exactly two members in the list. 
    "team_members": [
        {
            "name": "Qianbin Dong",
            "student_id": "1511935",
            "email": "QIANBIND@student.unimelb.edu.au" # Must be @student.unimelb.edu.au address
        },
        {
            "name": "Xiangdi (Allie) Hu",
            "student_id": "1524339",
            "email": "xiangdih@student.unimelb.edu.au" # Must be @student.unimelb.edu.au address
        }
    ],
}
